import { lazy, Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import Index from "./pages/Index.tsx";
import ScrollToTop from "./components/ScrollToTop";

const queryClient = new QueryClient();
const BuildingPage = lazy(() => import("./pages/BuildingPage.tsx"));
const AreaPage = lazy(() => import("./pages/AreaPage.tsx"));
const ExplorePage = lazy(() => import("./pages/ExplorePage.tsx"));
const IntentPage = lazy(() => import("./pages/IntentPage.tsx"));
const JournalPage = lazy(() => import("./pages/JournalPage.tsx"));
const PrivacyPage = lazy(() => import("./pages/PrivacyPage.tsx"));
const TermsPage = lazy(() => import("./pages/TermsPage.tsx"));
const NotFound = lazy(() => import("./pages/NotFound.tsx"));

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <ScrollToTop />
        <div className="relative z-10">
          <Suspense fallback={<div className="min-h-screen bg-background" />}>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/buy" element={<IntentPage mode="buy" />} />
              <Route path="/rent" element={<IntentPage mode="rent" />} />
              <Route path="/sell" element={<IntentPage mode="sell" />} />
              <Route path="/explore" element={<ExplorePage />} />
              <Route path="/building/:slug" element={<BuildingPage />} />
              <Route path="/area/:slug" element={<AreaPage />} />
              <Route path="/journal" element={<JournalPage />} />
              <Route path="/privacy" element={<PrivacyPage />} />
              <Route path="/terms" element={<TermsPage />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </Suspense>
        </div>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
