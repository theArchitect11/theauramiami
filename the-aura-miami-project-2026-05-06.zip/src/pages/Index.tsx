import Navbar from "@/components/aura/Navbar";
import Hero from "@/components/aura/Hero";
import AreaExplorer from "@/components/aura/AreaExplorer";
import JournalPreview from "@/components/aura/JournalPreview";
import Strategy from "@/components/aura/Strategy";
import Process from "@/components/aura/Process";
import ConsultationSection from "@/components/aura/ConsultationSection";
import FinalCta from "@/components/aura/FinalCta";
import Footer from "@/components/aura/Footer";

const Index = () => {
  return (
    <main className="min-h-screen bg-background animate-fade-in">
      <Navbar />
      <Hero />
      <AreaExplorer />
      <JournalPreview />
      <Strategy />
      <Process />
      <ConsultationSection />
      <FinalCta />
      <Footer />
    </main>
  );
};

export default Index;
