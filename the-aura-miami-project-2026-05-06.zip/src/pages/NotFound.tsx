import { useLocation } from "react-router-dom";
import { useEffect } from "react";
import Navbar from "@/components/aura/Navbar";
import Footer from "@/components/aura/Footer";

const NotFound = () => {
  const location = useLocation();

  useEffect(() => {
    console.error("404 Error: User attempted to access non-existent route:", location.pathname);
  }, [location.pathname]);

  return (
    <main className="min-h-screen bg-background animate-fade-in">
      <Navbar />
      <section className="min-h-[72vh] flex items-center justify-center px-6 pt-28">
        <div className="text-center max-w-xl">
          <p className="eyebrow mb-5">Not Found</p>
          <h1 className="serif text-6xl md:text-8xl gold-text mb-6">404</h1>
          <p className="text-muted-foreground leading-relaxed mb-8">
            This page is not part of the current private residence guide.
          </p>
          <a
            href="/"
            className="inline-flex items-center justify-center px-8 py-4 border border-primary/50 text-primary text-xs uppercase tracking-[0.25em] hover:bg-primary hover:text-primary-foreground transition-all duration-500"
          >
            Return Home
          </a>
        </div>
      </section>
      <Footer />
    </main>
  );
};

export default NotFound;
