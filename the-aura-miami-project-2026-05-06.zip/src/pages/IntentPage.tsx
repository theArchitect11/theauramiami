import { Link } from "react-router-dom";
import {
  ArrowRight,
  Bath,
  Bed,
  HandCoins,
  Home,
  KeyRound,
  Maximize2,
} from "lucide-react";
import Navbar from "@/components/aura/Navbar";
import Footer from "@/components/aura/Footer";
import ConciergeSearchBar from "@/components/aura/ConciergeSearchBar";
import { AREAS } from "@/data/areas";
import { BUILDINGS, formatPrice, type Listing } from "@/data/buildings";

type IntentMode = "buy" | "rent" | "sell";

type IntentPageProps = {
  mode: IntentMode;
};

type Profile = Listing & {
  buildingName: string;
  buildingSlug: string;
  areaSlug?: string;
};

const pageContent = {
  buy: {
    eyebrow: "Buy",
    title: "Find the right Miami residence to purchase.",
    accent: "purchase",
    body: "Compare curated buildings, price bands, views, and neighborhoods before we verify the strongest current matches privately.",
    intent: "buy",
    profileLabel: "Purchase Units",
    cta: "Request Purchase Match",
    Icon: Home,
  },
  rent: {
    eyebrow: "Rent",
    title: "Lease the right Miami residence without the noise.",
    accent: "lease",
    body: "Browse rent-focused residence profiles, seasonal possibilities, and annual lease examples before the concierge flow verifies what is actually available.",
    intent: "lease",
    profileLabel: "Rental Units",
    cta: "Request Lease Match",
    Icon: KeyRound,
  },
  sell: {
    eyebrow: "Sell",
    title: "Prepare a private seller strategy for your residence.",
    accent: "seller",
    body: "Start with the address. We can route your request for valuation context, positioning, buyer fit, and whether a quiet off-market path makes sense.",
    intent: "sell",
    profileLabel: "Seller Strategy",
    cta: "Enter Selling Address",
    Icon: HandCoins,
  },
} as const;

const getProfiles = (mode: IntentMode): Profile[] => {
  const listingType = mode === "rent" ? "rent" : "sale";
  return BUILDINGS.flatMap((building) =>
    building.listings
      .filter((listing) => listing.type === listingType)
      .map((listing) => ({
        ...listing,
        buildingName: building.name,
        buildingSlug: building.slug,
        areaSlug: building.areaSlug,
      })),
  ).slice(0, 6);
};

const IntentPage = ({ mode }: IntentPageProps) => {
  const content = pageContent[mode];
  const profiles = getProfiles(mode);
  const Icon = content.Icon;
  const formUrl = `/?${new URLSearchParams({
    intent: content.intent,
    interest:
      mode === "sell"
        ? "Selling address"
        : mode === "rent"
          ? "Rental residence search"
          : "Purchase residence search",
  }).toString()}#consultation`;

  return (
    <main className="min-h-screen bg-background animate-fade-in">
      <Navbar />

      <section className="relative pt-32 md:pt-40 pb-14 md:pb-20 border-b border-primary/10 overflow-hidden">
        <div className="absolute -top-40 right-0 w-[600px] h-[600px] bg-primary/8 rounded-full blur-3xl pointer-events-none" />
        <div className="container mx-auto px-5 sm:px-6 relative">
          <div className="max-w-4xl">
            <div className="flex items-center gap-3 mb-6">
              <span className="flex h-11 w-11 items-center justify-center rounded-full border border-primary/25 bg-primary/10 text-primary">
                <Icon className="h-5 w-5" strokeWidth={1.5} />
              </span>
              <p className="eyebrow text-[10px] sm:text-xs">{content.eyebrow}</p>
            </div>
            <h1 className="serif text-5xl sm:text-6xl md:text-7xl leading-[0.98] mb-7">
              {content.title.split(content.accent)[0]}
              <span className="italic text-primary">{content.accent}</span>
              {content.title.split(content.accent)[1]}
            </h1>
            <p className="text-foreground/75 text-base md:text-lg leading-relaxed font-light max-w-3xl">
              {content.body}
            </p>
          </div>
        </div>
      </section>

      <ConciergeSearchBar placement="inline" />

      {mode === "sell" ? (
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-5 sm:px-6">
            <div className="grid lg:grid-cols-[1fr_0.85fr] gap-px bg-primary/12 border border-primary/12">
              <div className="bg-background p-8 md:p-12">
                <p className="eyebrow mb-5 text-[10px] sm:text-xs">Seller Intake</p>
                <h2 className="serif text-4xl md:text-5xl leading-tight mb-6">
                  The first signal is the address.
                </h2>
                <p className="text-muted-foreground leading-relaxed font-light max-w-2xl">
                  Once we know the property, the response can be specific:
                  building, view line, competing inventory, likely buyer segment,
                  rental alternative, and whether the strongest strategy is public,
                  private, or off-market.
                </p>
              </div>
              <div className="bg-background p-8 md:p-12 flex flex-col justify-center">
                <Link
                  to={formUrl}
                  className="group inline-flex items-center justify-center px-8 py-4 bg-gradient-gold text-primary-foreground text-xs uppercase tracking-[0.25em] font-medium shadow-gold hover:shadow-[0_0_80px_-5px_hsl(var(--gold)/0.6)] transition-all duration-500"
                >
                  {content.cta}
                  <ArrowRight className="w-3.5 h-3.5 ml-3 transition-transform duration-500 group-hover:translate-x-1" strokeWidth={1.5} />
                </Link>
              </div>
            </div>
          </div>
        </section>
      ) : (
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-5 sm:px-6">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
              <div>
                <p className="eyebrow mb-4 text-[10px] sm:text-xs">{content.profileLabel}</p>
                <h2 className="serif text-3xl md:text-4xl leading-[1.1]">
                  {mode === "rent" ? "Lease profiles only." : "Purchase profiles only."}
                </h2>
              </div>
              <p className="text-xs text-muted-foreground/70 italic max-w-md">
                These are editorial residence profiles, not live IDX inventory.
                The concierge flow verifies exact availability after inquiry.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-px md:bg-primary/15 md:border md:border-primary/15">
              {profiles.map((profile) => (
                <article
                  key={`${profile.buildingSlug}-${profile.id}`}
                  className="bg-background border border-primary/12 md:border-0 p-6 sm:p-7 flex flex-col group hover:bg-secondary/40 transition-colors duration-500"
                >
                  <div className="flex items-start justify-between gap-4 mb-5">
                    <div>
                      <span className="text-[9px] uppercase tracking-[0.24em] text-primary/80">
                        {mode === "rent" ? "Representative Lease" : "Representative Purchase"}
                      </span>
                      <h3 className="serif text-2xl text-foreground mt-2 leading-tight">
                        {profile.buildingName}
                      </h3>
                    </div>
                    <span className="text-[9px] uppercase tracking-[0.2em] px-2 py-1 border border-primary/30 text-primary/80">
                      {profile.id}
                    </span>
                  </div>

                  <div className="serif text-4xl md:text-3xl text-foreground leading-tight mb-1">
                    {mode === "rent" ? `$${profile.price.toLocaleString()}/mo` : formatPrice(profile.price)}
                  </div>
                  <p className="text-[11px] uppercase tracking-[0.25em] text-foreground/55 mb-6">
                    {profile.view}
                  </p>

                  <div className="grid grid-cols-3 gap-2 text-foreground/80 text-sm font-light mb-8 border-y border-primary/10 py-4">
                    <span className="flex items-center gap-1.5">
                      <Bed className="w-3.5 h-3.5 text-primary/70" strokeWidth={1.5} />
                      {profile.bedrooms} BD
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Bath className="w-3.5 h-3.5 text-primary/70" strokeWidth={1.5} />
                      {profile.bathrooms} BA
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Maximize2 className="w-3.5 h-3.5 text-primary/70" strokeWidth={1.5} />
                      {profile.sqft.toLocaleString()} sf
                    </span>
                  </div>

                  <Link
                    to={`/building/${profile.buildingSlug}?intent=${content.intent}`}
                    className="mt-auto inline-flex items-center justify-between border border-primary/25 px-4 py-3 text-[10px] uppercase tracking-[0.22em] text-foreground/80 group-hover:text-primary group-hover:border-primary/50 transition-colors"
                  >
                    Verify privately
                    <ArrowRight className="w-3.5 h-3.5 transition-transform duration-500 group-hover:translate-x-1" strokeWidth={1.5} />
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="py-16 md:py-24 border-t border-primary/10">
        <div className="container mx-auto px-5 sm:px-6">
          <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-10">
            <div>
              <p className="eyebrow mb-4 text-[10px] sm:text-xs">Areas</p>
              <h2 className="serif text-3xl md:text-4xl leading-[1.1]">
                Choose the market, keep the intent.
              </h2>
            </div>
            <Link
              to={formUrl}
              className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.24em] text-primary hover:text-foreground transition-colors"
            >
              {content.cta} <ArrowRight className="w-4 h-4" strokeWidth={1.5} />
            </Link>
          </div>

          <div className="grid grid-cols-1 min-[430px]:grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4 md:gap-6">
            {AREAS.map((area) => (
              <Link
                key={area.slug}
                to={`/area/${area.slug}?intent=${content.intent}`}
                className="group relative overflow-hidden rounded-md border border-primary/15 hover:border-primary/60 transition-all duration-500 hover:shadow-gold hover:-translate-y-1 bg-card"
              >
                <div className="relative aspect-[16/11] min-[430px]:aspect-[3/4] overflow-hidden bg-muted">
                  <img
                    src={area.image}
                    alt={`${area.name}, Miami`}
                    loading="lazy"
                    width={1280}
                    height={896}
                    className="w-full h-full object-cover transition-transform duration-1000 ease-out group-hover:scale-[1.12]"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-card via-card/45 to-transparent" />
                </div>
                <div className="absolute inset-x-0 bottom-0 p-4 md:p-5 bg-gradient-to-t from-card/95 via-card/70 to-transparent">
                  <h3 className="serif text-2xl min-[430px]:text-xl md:text-2xl text-foreground group-hover:text-primary transition-colors duration-500 leading-tight">
                    {area.name}
                  </h3>
                  <p className="text-[10px] uppercase tracking-[0.2em] md:tracking-[0.25em] text-foreground/75 mt-1.5 leading-snug">
                    {area.signature}
                  </p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </main>
  );
};

export default IntentPage;
