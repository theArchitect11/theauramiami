import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { ArrowRight, Search, SlidersHorizontal } from "lucide-react";
import Navbar from "@/components/aura/Navbar";
import Footer from "@/components/aura/Footer";
import { AREAS } from "@/data/areas";

const intents = [
  { label: "Buy", value: "buy" },
  { label: "Rent", value: "lease" },
  { label: "Sell", value: "sell" },
] as const;

const tags = [
  "Oceanfront",
  "Bayfront",
  "Branded",
  "Quiet Luxury",
  "New Development",
  "Investor",
  "Design",
  "Walkable",
];

const groups = [
  "North Ocean Corridor",
  "Miami Mainland Core",
  "Miami Beach",
  "Coral Gables / Grove",
  "Island & Key Corridors",
];

const normalize = (value: string) => value.toLowerCase().replace(/[^a-z0-9]/g, "");

const ExplorePage = () => {
  const [intent, setIntent] = useState<(typeof intents)[number]["value"]>("buy");
  const [selectedArea, setSelectedArea] = useState("all");
  const [activeTag, setActiveTag] = useState("All");
  const [query, setQuery] = useState("");

  const areaOptions = useMemo(
    () => [...AREAS].sort((a, b) => (a.launchPriority ?? 99) - (b.launchPriority ?? 99)),
    [],
  );

  const filteredAreas = useMemo(() => {
    const q = normalize(query);
    return AREAS.filter((area) => {
      const matchesArea = selectedArea === "all" || area.slug === selectedArea;
      const matchesTag =
        activeTag === "All" || area.lifestyleTags?.includes(activeTag);
      const searchable = [
        area.name,
        area.signature,
        area.areaType,
        area.regionGroup,
        ...(area.aliases ?? []),
        ...area.buildings,
      ]
        .filter(Boolean)
        .map((item) => normalize(String(item)))
        .join(" ");
      const matchesQuery = !q || searchable.includes(q);
      return matchesArea && matchesTag && matchesQuery;
    }).sort((a, b) => (a.launchPriority ?? 99) - (b.launchPriority ?? 99));
  }, [activeTag, query, selectedArea]);

  return (
    <main className="min-h-screen bg-background animate-fade-in">
      <Navbar />

      <section className="relative pt-32 md:pt-40 pb-14 md:pb-20 border-b border-primary/10 overflow-hidden">
        <div className="container mx-auto max-w-6xl px-5 sm:px-6 relative">
          <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 md:gap-14 items-end">
            <div>
              <p className="eyebrow mb-5 text-[10px] sm:text-xs">AURA Map</p>
              <h1 className="serif text-4xl sm:text-5xl md:text-6xl leading-[1.02] mb-6">
                Start with the{" "}
                <span className="italic text-primary">area.</span>
              </h1>
            </div>
            <p className="text-foreground/75 text-base md:text-lg leading-relaxed font-light max-w-2xl">
              Choose Bal Harbour, Sunny Isles, Midtown, Brickell, Coconut Grove,
              or another AURA area first. Then refine by buy, rent, sell, and
              lifestyle signals like oceanfront, bayfront, branded, or design-led.
            </p>
          </div>
        </div>
      </section>

      <section className="relative z-20 border-b border-primary/15 bg-background/94 backdrop-blur-md">
        <div className="container mx-auto max-w-6xl px-5 sm:px-6 py-4">
          <div className="grid gap-4">
            <div className="flex min-w-0 flex-col gap-3 lg:grid lg:grid-cols-[auto_minmax(0,36rem)] lg:items-center lg:justify-between">
              <div className="inline-grid w-fit max-w-full grid-cols-3 gap-1 rounded-full border border-primary/15 bg-background/45 p-1">
                {intents.map((item) => (
                  <button
                    key={item.value}
                    onClick={() => setIntent(item.value)}
                    className={`min-w-[72px] rounded-full px-3 py-2 text-[10px] uppercase tracking-[0.18em] transition-all sm:min-w-[82px] sm:px-4 sm:tracking-[0.22em] ${
                      intent === item.value
                        ? "bg-gradient-gold text-primary-foreground shadow-gold"
                        : "text-foreground/70 hover:text-primary hover:bg-primary/10"
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>

              <div className="flex min-w-0 w-full max-w-[36rem] items-center gap-3 rounded-full border border-primary/15 bg-input/55 px-4 py-2.5">
                <Search className="h-4 w-4 shrink-0 text-primary/80" strokeWidth={1.5} />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search Bal Harbor, Sunny Island, Missoni, SoFi, Brickel..."
                  className="min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/60"
                />
              </div>
            </div>

            <div>
              <div className="mb-2 flex items-center justify-between gap-4">
                <span className="text-[10px] uppercase tracking-[0.24em] text-primary/80">
                  Area first
                </span>
                <span className="hidden sm:inline text-[10px] uppercase tracking-[0.18em] text-muted-foreground/65">
                  {filteredAreas.length} visible
                </span>
              </div>
              <div className="flex flex-wrap gap-2 pb-1">
                <button
                  onClick={() => setSelectedArea("all")}
                  className={`rounded-full border px-3 py-2 text-[9px] uppercase tracking-[0.16em] transition-colors sm:px-4 sm:text-[10px] sm:tracking-[0.18em] ${
                    selectedArea === "all"
                      ? "border-primary bg-primary/15 text-primary"
                      : "border-primary/15 text-foreground/70 hover:text-primary hover:border-primary/45"
                  }`}
                >
                  All Areas
                </button>
                {areaOptions.map((area) => (
                  <button
                    key={area.slug}
                    onClick={() => setSelectedArea(area.slug)}
                    className={`rounded-full border px-3 py-2 text-[9px] uppercase tracking-[0.16em] transition-colors sm:px-4 sm:text-[10px] sm:tracking-[0.18em] ${
                      selectedArea === area.slug
                        ? "border-primary bg-primary/15 text-primary"
                        : "border-primary/15 text-foreground/70 hover:text-primary hover:border-primary/45"
                    }`}
                  >
                    {area.name}
                  </button>
                ))}
              </div>
            </div>

            <div className="border-t border-primary/10 pt-3">
              <div className="mb-2 flex items-center gap-2">
                <SlidersHorizontal className="h-4 w-4 shrink-0 text-primary/70" strokeWidth={1.5} />
                <span className="text-[10px] uppercase tracking-[0.22em] text-muted-foreground/70">
                  Secondary refinement
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2 pb-1 lg:pb-0">
                {["All", ...tags].map((tag) => (
                  <button
                    key={tag}
                    onClick={() => setActiveTag(tag)}
                    className={`rounded-full border px-3 py-2 text-[9px] uppercase tracking-[0.16em] transition-colors sm:tracking-[0.18em] ${
                      activeTag === tag
                        ? "border-primary/70 bg-primary/10 text-primary"
                        : "border-primary/10 text-foreground/55 hover:text-primary"
                    }`}
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-14 md:py-20">
        <div className="container mx-auto max-w-6xl px-5 sm:px-6">
          {groups.map((group) => {
            const groupAreas = filteredAreas.filter(
              (area) => area.regionGroup === group,
            );
            if (groupAreas.length === 0) return null;

            return (
              <div key={group} className="mb-14 last:mb-0">
                <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-7">
                  <div>
                    <p className="eyebrow mb-3 text-[10px] sm:text-xs">{group}</p>
                    <h2 className="serif text-2xl md:text-4xl leading-tight">
                      {groupAreas.length} curated {groupAreas.length === 1 ? "area" : "areas"}
                    </h2>
                  </div>
                  <p className="text-xs text-muted-foreground/70 italic max-w-sm">
                    Oceanfront, bayfront, and branded signals refine the area story.
                  </p>
                </div>

                <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
                  {groupAreas.map((area) => (
                    <Link
                      key={area.slug}
                      to={`/area/${area.slug}?intent=${intent}`}
                      className="group overflow-hidden border border-primary/12 bg-card/65 transition-[border-color,transform,box-shadow] duration-300 hover:-translate-y-1 hover:border-primary/45"
                    >
                      <div className="relative aspect-[16/9] overflow-hidden bg-muted">
                        <img
                          src={area.image}
                          alt={`${area.name}, Miami`}
                          loading="lazy"
                          decoding="async"
                          width={960}
                          height={540}
                          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
                        />
                        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
                        <div className="absolute left-5 top-5 flex flex-wrap gap-2">
                          {(area.lifestyleTags ?? []).slice(0, 3).map((tag) => (
                            <span
                              key={tag}
                              className="rounded-full border border-primary/25 bg-background/60 px-3 py-1 text-[9px] uppercase tracking-[0.18em] text-primary backdrop-blur"
                            >
                              {tag}
                            </span>
                          ))}
                        </div>
                      </div>
                      <div className="p-5">
                        <div className="flex items-start justify-between gap-4 mb-3">
                          <div>
                            <h3 className="serif text-2xl leading-tight group-hover:text-primary transition-colors">
                              {area.name}
                            </h3>
                            <p className="text-[10px] uppercase tracking-[0.22em] text-foreground/55 mt-2">
                              {area.areaType}
                            </p>
                          </div>
                          <span className="text-[9px] uppercase tracking-[0.18em] text-primary/80">
                            {area.buildings.length} buildings
                          </span>
                        </div>
                        <p className="text-sm leading-relaxed text-muted-foreground mb-5">
                          {area.shortDescription}
                        </p>
                        <div className="flex items-center justify-between border-t border-primary/10 pt-4">
                          <span className="text-[10px] uppercase tracking-[0.22em] text-foreground/60">
                            {intent === "lease" ? "Rent mode" : intent === "sell" ? "Sell mode" : "Buy mode"}
                          </span>
                          <ArrowRight className="h-4 w-4 text-primary/75 transition-transform group-hover:translate-x-1" strokeWidth={1.5} />
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </section>

      <Footer />
    </main>
  );
};

export default ExplorePage;
