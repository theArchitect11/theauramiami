// Set VITE_N8N_WEBHOOK_URL in the deployment environment before launch.
export const N8N_WEBHOOK_URL: string =
  (import.meta.env.VITE_N8N_WEBHOOK_URL as string | undefined) || "";

export const isLeadWebhookConfigured = Boolean(N8N_WEBHOOK_URL.trim());
