import { Compass, TrendingUp, Users } from "lucide-react";

const cards = [
  {
    icon: Compass,
    title: "Relocation Architecture",
    body: "A structured plan for timing, market orientation, neighborhood fit, and lifestyle priorities — mapped before you ever board a flight.",
  },
  {
    icon: TrendingUp,
    title: "Investment Clarity",
    body: "Clear-eyed perspective on submarkets, pricing dynamics, and asset positioning. We help you understand what you are actually buying.",
  },
  {
    icon: Users,
    title: "Private Access",
    body: "Direct introductions to vetted agents, attorneys, lenders, and operators across South Florida — curated, not crowdsourced.",
  },
];

const Strategy = () => {
  return (
    <section id="strategy" className="relative pt-10 md:pt-14 pb-24 md:pb-32 overflow-hidden scroll-mt-24">
      <div className="container mx-auto px-6 relative">
        <div className="max-w-3xl mb-14 md:mb-20">
          <p className="eyebrow mb-6">Strategy</p>
          <h2 className="serif text-4xl md:text-6xl leading-[1.05] mb-8">
            Built for people who want{" "}
            <span className="italic gold-text">more than a property search.</span>
          </h2>
          <p className="text-muted-foreground text-base md:text-lg leading-relaxed max-w-2xl">
            South Florida is not just a market. It is a relocation, lifestyle,
            capital, and timing decision. This process is designed to help serious
            buyers move with confidence before they waste time across scattered
            portals and disconnected advice.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {cards.map((c, i) => (
            <div
              key={c.title}
              className="group bg-card/60 border border-primary/10 p-10 md:p-12 transition-[background-color,border-color,box-shadow,transform] duration-300 hover:-translate-y-1 hover:border-primary/30 hover:bg-card hover:shadow-elegant"
            >
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors duration-500">
                  <c.icon className="w-5 h-5 text-primary" strokeWidth={1.5} />
                </div>
                <span className="serif text-primary text-3xl">
                  0{i + 1}
                </span>
              </div>
              <h3 className="serif text-2xl md:text-3xl mb-4 text-foreground">
                {c.title}
              </h3>
              <p className="text-muted-foreground leading-relaxed text-sm md:text-base">
                {c.body}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Strategy;
