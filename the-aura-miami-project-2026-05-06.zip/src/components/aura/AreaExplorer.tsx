import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import { AREAS } from "@/data/areas";

const featuredAreaSlugs = [
  "sunny-isles",
  "aventura",
  "bal-harbour",
  "design-district",
  "brickell",
];

const AreaExplorer = () => {
  const featuredAreas = featuredAreaSlugs
    .map((slug) => AREAS.find((area) => area.slug === slug))
    .filter(Boolean);

  return (
    <section
      id="areas"
      className="relative py-20 md:py-32 overflow-hidden border-t border-primary/10 scroll-mt-32"
    >
      <div className="container mx-auto px-5 sm:px-6 relative">
        <div className="mb-10 md:mb-14 flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div className="max-w-3xl">
            <p className="eyebrow mb-5 md:mb-6 text-[10px] sm:text-xs">Explore Miami by Area</p>
            <h2 className="serif text-4xl sm:text-5xl leading-[1.05] md:leading-[1.1] mb-5 md:mb-6">
              Five launch corridors.{" "}
              <span className="italic text-primary">One curated lens.</span>
            </h2>
            <p className="text-foreground/75 text-sm sm:text-base md:text-lg leading-relaxed max-w-2xl font-light">
              Start with the areas that define AURA's first map, then open the
              complete guide when you want the wider South Florida index.
            </p>
          </div>
          <Link
            to="/explore"
            className="group inline-flex w-fit items-center gap-3 border border-primary/30 px-5 py-3 text-[10px] uppercase tracking-[0.24em] text-primary transition-all hover:border-primary hover:bg-primary/10"
          >
            View all areas
            <ArrowRight
              className="h-4 w-4 transition-transform group-hover:translate-x-1"
              strokeWidth={1.5}
            />
          </Link>
        </div>

        <div className="-mx-5 flex gap-4 overflow-x-auto px-5 pb-3 sm:mx-0 sm:grid sm:grid-cols-5 sm:px-0 sm:pb-0 md:gap-5">
          {featuredAreas.map((area) => (
            <Link
              key={area!.slug}
              to={`/area/${area!.slug}`}
              className="group relative h-[260px] w-[76vw] max-w-[330px] shrink-0 overflow-hidden rounded-md border border-primary/15 bg-card transition-[border-color,box-shadow,transform] duration-300 hover:-translate-y-1 hover:border-primary/60 hover:shadow-gold sm:h-[320px] sm:w-auto sm:max-w-none"
            >
              <div className="relative h-full overflow-hidden bg-muted">
                <img
                  src={area!.image}
                  alt={`${area!.name}, Miami`}
                  loading="lazy"
                  decoding="async"
                  width={1280}
                  height={896}
                  className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/45 to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-br from-primary/0 via-transparent to-transparent group-hover:from-primary/20 transition-all duration-700" />
                {/* Inner ring glow on hover */}
                <div className="absolute inset-0 rounded-md ring-0 group-hover:ring-1 ring-primary/40 transition-all duration-500 pointer-events-none" />
              </div>

              <div className="absolute inset-x-0 bottom-0 p-4 md:p-5 bg-gradient-to-t from-card/95 via-card/70 to-transparent">
                <h3 className="serif text-2xl min-[430px]:text-xl md:text-2xl text-foreground group-hover:text-primary transition-colors duration-500 leading-tight">
                  {area!.name}
                </h3>
                <p className="text-[10px] uppercase tracking-[0.2em] md:tracking-[0.25em] text-foreground/75 mt-1.5 leading-snug">
                  {area!.signature}
                </p>
                <div className="flex items-center justify-between mt-3 pt-3 border-t border-primary/15">
                  <span className="text-[9px] uppercase tracking-[0.24em] md:tracking-[0.3em] text-foreground/60">
                    {area!.buildings.length} buildings
                  </span>
                  <ArrowRight
                    className="w-3.5 h-3.5 text-primary/70 group-hover:text-primary group-hover:translate-x-1 transition-all duration-500"
                    strokeWidth={1.5}
                  />
                </div>
              </div>
            </Link>
          ))}
        </div>

        <p className="mt-8 md:mt-10 text-xs text-foreground/55 italic max-w-2xl leading-relaxed">
          A curated guide, not a public directory. Building lists are indicative
          and verified directly before any decision.
        </p>
      </div>
    </section>
  );
};

export default AreaExplorer;
