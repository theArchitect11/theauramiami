import { useMemo, useState } from "react";
import { Search, MapPin, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";
import { BUILDINGS, formatPrice } from "@/data/buildings";

const BuildingSearch = () => {
  const [query, setQuery] = useState("");

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return BUILDINGS;
    return BUILDINGS.filter(
      (b) =>
        b.name.toLowerCase().includes(q) ||
        b.neighborhood.toLowerCase().includes(q) ||
        b.architect.toLowerCase().includes(q) ||
        (b.profile?.searchAliases ?? []).some((alias) =>
          alias.toLowerCase().includes(q),
        )
    );
  }, [query]);

  return (
    <section
      id="buildings"
      className="relative py-24 md:py-32 overflow-hidden border-t border-primary/10"
    >
      <div className="absolute -top-32 -left-32 w-[500px] h-[500px] bg-primary/5 rounded-full blur-3xl pointer-events-none" />

      <div className="container mx-auto px-6 relative">
        <div className="max-w-3xl mb-12">
          <p className="eyebrow mb-6">Building Guide</p>
          <h2 className="serif text-4xl md:text-5xl leading-[1.1] mb-6">
            South Florida's most{" "}
            <span className="italic text-primary">coveted</span> addresses.
          </h2>
          <p className="text-muted-foreground text-base md:text-lg leading-relaxed max-w-2xl">
            Browse the editorial index. Pricing, availability, and matching
            residences are verified privately after inquiry.
          </p>
        </div>

        {/* Search bar */}
        <div className="relative max-w-2xl mb-12">
          <div className="glass-panel flex items-center gap-3 px-5 py-4">
            <Search className="w-5 h-5 text-primary shrink-0" strokeWidth={1.5} />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search a building, architect, or neighborhood…"
              className="flex-1 bg-transparent border-0 outline-none text-foreground placeholder:text-muted-foreground/70 text-sm md:text-base font-light tracking-wide"
              aria-label="Search buildings"
            />
            {query && (
              <button
                onClick={() => setQuery("")}
                className="text-xs uppercase tracking-[0.25em] text-muted-foreground hover:text-primary transition-colors"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Building grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-px bg-primary/10 border border-primary/10">
          {results.length === 0 ? (
            <div className="col-span-full bg-background p-16 text-center">
              <p className="serif text-2xl text-foreground mb-3">
                No matches in our current index.
              </p>
              <p className="text-muted-foreground text-sm max-w-md mx-auto">
                Our private list extends beyond what we publish. Request a
                consultation to discuss the building you have in mind.
              </p>
            </div>
          ) : (
            results.map((b) => (
              <Link
                key={b.slug}
                to={`/building/${b.slug}`}
                className="group bg-background p-8 md:p-10 text-left hover:bg-secondary/40 transition-colors duration-700"
              >
                <div className="flex items-center gap-3 mb-6 text-muted-foreground">
                  <MapPin className="w-3.5 h-3.5 text-primary" strokeWidth={1.5} />
                  <span className="text-[10px] uppercase tracking-[0.3em]">
                    {b.neighborhood} · {b.city}
                  </span>
                </div>
                <h3 className="serif text-2xl md:text-3xl mb-2 text-foreground group-hover:text-primary transition-colors duration-500">
                  {b.name}
                </h3>
                <p className="text-sm text-muted-foreground/80 mb-6 font-light">
                  {b.architect} · {b.year}
                </p>
                <div className="hairline mb-6" />
                <div className="flex items-center justify-between text-xs">
                  <div>
                    <div className="text-[9px] uppercase tracking-[0.3em] text-muted-foreground/70 mb-1">
                      Guide from
                    </div>
                    <div className="text-foreground font-light">
                      {formatPrice(b.priceRange.saleMin)}
                    </div>
                  </div>
                  <ArrowRight
                    className="w-4 h-4 text-primary/70 group-hover:text-primary group-hover:translate-x-1 transition-all duration-500"
                    strokeWidth={1.5}
                  />
                </div>
              </Link>
            ))
          )}
        </div>

        <p className="mt-8 text-xs text-muted-foreground/60 italic max-w-2xl">
          Building information is editorial and non-MLS. Live availability is
          verified through licensed partners after inquiry.
        </p>
      </div>
    </section>
  );
};

export default BuildingSearch;
