import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { ArrowRight, Building2, HandCoins, Home, KeyRound, MapPin, Search } from "lucide-react";
import { AREAS } from "@/data/areas";
import { BUILDINGS } from "@/data/buildings";

type Intent = "buy" | "lease" | "sell";

type ConciergeSearchBarProps = {
  visible?: boolean;
  placement?: "floating" | "inline";
};

type Suggestion = {
  kind: "building" | "area";
  slug: string;
  title: string;
  sub: string;
};

const intentOptions = [
  { label: "Buy", intent: "buy", Icon: Home },
  { label: "Rent", intent: "lease", Icon: KeyRound },
  { label: "Sell", intent: "sell", Icon: HandCoins },
] as const;

const inquiryCopy: Record<Intent, string> = {
  buy: "Purchase residence search",
  lease: "Rental residence search",
  sell: "Selling address",
};

const ConciergeSearchBar = ({ visible = true, placement = "floating" }: ConciergeSearchBarProps) => {
  const [intent, setIntent] = useState<Intent>("buy");
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const blurTimeout = useRef<number | null>(null);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const currentIntent = new URLSearchParams(location.search).get("intent");
    if (currentIntent === "buy" || currentIntent === "lease" || currentIntent === "sell") {
      setIntent(currentIntent);
    }
  }, [location.search]);

  const suggestions = useMemo<Suggestion[]>(() => {
    const q = query.trim().toLowerCase();
    if (!q || intent === "sell") return [];

    const areas = AREAS.filter(
      (area) =>
        area.name.toLowerCase().includes(q) ||
        area.signature.toLowerCase().includes(q),
    )
      .slice(0, 3)
      .map((area) => ({
        kind: "area" as const,
        slug: area.slug,
        title: area.name,
        sub: area.signature,
      }));

    const buildings = BUILDINGS.filter(
      (building) =>
        building.name.toLowerCase().includes(q) ||
        building.neighborhood.toLowerCase().includes(q) ||
        building.city.toLowerCase().includes(q) ||
        (building.profile?.searchAliases ?? []).some((alias) =>
          alias.toLowerCase().includes(q),
        ),
    )
      .slice(0, 5)
      .map((building) => ({
        kind: "building" as const,
        slug: building.slug,
        title: building.name,
        sub: `${building.neighborhood} · ${building.city}`,
      }));

    return [...areas, ...buildings].slice(0, 6);
  }, [intent, query]);

  const inquiryUrl = (nextIntent = intent, nextInterest = query.trim() || inquiryCopy[nextIntent]) => {
    const params = new URLSearchParams({
      intent: nextIntent,
      interest: nextInterest,
    });
    return `/?${params.toString()}#consultation`;
  };

  const submitInquiry = () => {
    navigate(inquiryUrl());
    setOpen(false);
  };

  const chooseSuggestion = (suggestion: Suggestion) => {
    const params = new URLSearchParams({ intent });
    navigate(
      suggestion.kind === "building"
        ? `/building/${suggestion.slug}?${params.toString()}`
        : `/area/${suggestion.slug}?${params.toString()}`,
    );
    setOpen(false);
    setQuery("");
  };

  const onIntentClick = (nextIntent: Intent) => {
    setIntent(nextIntent);
    setOpen(false);
    if (nextIntent === "sell") {
      navigate(inquiryUrl(nextIntent, "Selling address"));
      return;
    }

    const params = new URLSearchParams(location.search);
    params.set("intent", nextIntent);
    navigate(`${location.pathname}?${params.toString()}${location.hash}`);
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setOpen(true);
      setActiveIndex((i) => Math.min(i + 1, suggestions.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const pick = suggestions[activeIndex];
      if (pick) {
        chooseSuggestion(pick);
      } else {
        submitInquiry();
      }
    } else if (e.key === "Escape") {
      setOpen(false);
    }
  };

  return (
    <div
      className={
        placement === "inline"
          ? "relative z-20 border-y border-primary/15 bg-background/92 backdrop-blur-xl shadow-elegant"
          : `absolute left-0 right-0 top-full border-b border-primary/15 bg-background/92 backdrop-blur-xl shadow-elegant transition-all duration-500 ${
              visible
                ? "translate-y-0 opacity-100 pointer-events-auto"
                : "-translate-y-3 opacity-0 pointer-events-none"
            }`
      }
    >
      <div className="container mx-auto px-4 sm:px-6 py-3">
        <div className="mx-auto flex max-w-5xl flex-col gap-2 sm:flex-row sm:items-center">
          <div className="grid grid-cols-3 gap-1 rounded-full border border-primary/15 bg-background/45 p-1">
            {intentOptions.map(({ label, intent: optionIntent, Icon }) => {
              const isActive = intent === optionIntent;
              return (
                <button
                  key={optionIntent}
                  type="button"
                  onClick={() => onIntentClick(optionIntent)}
                  className={`inline-flex items-center justify-center gap-1.5 rounded-full px-3 py-2 text-[9px] uppercase tracking-[0.2em] transition-all duration-300 ${
                    isActive
                      ? "bg-gradient-gold text-primary-foreground shadow-gold"
                      : "text-foreground/70 hover:text-primary hover:bg-primary/10"
                  }`}
                >
                  <Icon className="h-3.5 w-3.5" strokeWidth={1.5} />
                  {label}
                </button>
              );
            })}
          </div>

          <div className="relative min-w-0 flex-1">
            <div className="flex items-center gap-3 rounded-full border border-primary/15 bg-input/55 px-4 py-2.5 focus-within:border-primary/60 transition-colors">
              <Search className="h-4 w-4 shrink-0 text-primary/80" strokeWidth={1.5} />
              <input
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setOpen(true);
                  setActiveIndex(0);
                }}
                onFocus={() => setOpen(true)}
                onBlur={() => {
                  blurTimeout.current = window.setTimeout(() => setOpen(false), 140);
                }}
                onKeyDown={onKeyDown}
                placeholder={
                  intent === "sell"
                    ? "Enter selling address"
                    : "Search building or neighborhood"
                }
                className="min-w-0 flex-1 bg-transparent text-sm text-foreground outline-none placeholder:text-muted-foreground/60"
                aria-label="Search buildings and neighborhoods"
              />
              <button
                type="button"
                onMouseDown={(e) => e.preventDefault()}
                onClick={submitInquiry}
                className="inline-flex items-center gap-2 text-[9px] uppercase tracking-[0.22em] text-primary hover:text-primary-glow"
              >
                Inquire <ArrowRight className="h-3.5 w-3.5" strokeWidth={1.5} />
              </button>
            </div>

            {open && suggestions.length > 0 && (
              <div className="absolute left-0 right-0 top-full z-50 mt-2 overflow-hidden rounded-2xl border border-primary/20 bg-background/95 shadow-elegant backdrop-blur-xl">
                {suggestions.map((suggestion, index) => {
                  const Icon = suggestion.kind === "building" ? Building2 : MapPin;
                  const active = index === activeIndex;
                  return (
                    <button
                      key={`${suggestion.kind}-${suggestion.slug}`}
                      type="button"
                      onMouseEnter={() => setActiveIndex(index)}
                      onMouseDown={(e) => {
                        e.preventDefault();
                        if (blurTimeout.current) window.clearTimeout(blurTimeout.current);
                        chooseSuggestion(suggestion);
                      }}
                      className={`flex w-full items-center justify-between gap-4 border-b border-primary/10 px-4 py-3 text-left last:border-0 ${
                        active ? "bg-primary/12" : "hover:bg-primary/8"
                      }`}
                    >
                      <span className="flex min-w-0 items-center gap-3">
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                          <Icon className="h-4 w-4" strokeWidth={1.5} />
                        </span>
                        <span className="min-w-0">
                          <span className="block truncate serif text-base text-foreground">
                            {suggestion.title}
                          </span>
                          <span className="block truncate text-[10px] uppercase tracking-[0.22em] text-foreground/55">
                            {suggestion.sub}
                          </span>
                        </span>
                      </span>
                      <ArrowRight className="h-4 w-4 shrink-0 text-primary/70" strokeWidth={1.5} />
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConciergeSearchBar;
