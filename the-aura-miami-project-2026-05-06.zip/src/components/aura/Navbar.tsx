import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import BrandMark from "./BrandMark";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      window.requestAnimationFrame(() => {
        setScrolled((current) => {
          const next = window.scrollY > 30;
          return current === next ? current : next;
        });
        ticking = false;
      });
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 border-b border-primary/45 bg-[#111721]/95 shadow-[0_18px_60px_-36px_hsl(var(--gold)/0.45)] backdrop-blur-md transition-all duration-500 ${
        scrolled
          ? "py-3"
          : "py-4 md:py-5"
      }`}
    >
      <nav className="container mx-auto flex items-center justify-between px-5 sm:px-6">
        <a href="/#top" aria-label="The Aura Miami home">
          <BrandMark />
        </a>
        <div className="hidden md:flex items-center gap-8 text-xs uppercase tracking-[0.18em] text-foreground/90">
          <a href="/explore" className="hover:text-primary transition-colors">Explore</a>
          <a href="/journal" className="hover:text-primary transition-colors">Journal</a>
          <a href="/#strategy" className="hover:text-primary transition-colors">Strategy</a>
          <a href="/#process" className="hover:text-primary transition-colors">Process</a>
        </div>
        <div className="flex items-center gap-4">
          <a
            href="/#consultation"
            className="hidden sm:inline-flex text-[11px] uppercase tracking-[0.25em] border border-primary/75 bg-[#1a1f29] px-4 py-2.5 text-primary hover:bg-primary hover:text-primary-foreground transition-all duration-500"
          >
            Inquire
          </a>
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="md:hidden w-10 h-10 flex items-center justify-center border border-primary/55 bg-[#1a1f29] text-foreground hover:text-primary hover:border-primary/75 transition-colors"
            aria-label="Toggle menu"
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden absolute top-full left-0 right-0 border-b border-primary/25 bg-[#111721]/98 px-5 py-5 shadow-elegant">
          <div className="flex flex-col divide-y divide-primary/10 text-xs uppercase tracking-[0.22em] text-foreground/90">
            <a href="/explore" onClick={() => setMobileOpen(false)} className="hover:text-primary transition-colors py-4">Explore</a>
            <a href="/journal" onClick={() => setMobileOpen(false)} className="hover:text-primary transition-colors py-4">Journal</a>
            <a href="/#strategy" onClick={() => setMobileOpen(false)} className="hover:text-primary transition-colors py-4">Strategy</a>
            <a href="/#process" onClick={() => setMobileOpen(false)} className="hover:text-primary transition-colors py-4">Process</a>
            <a
              href="/#consultation"
              onClick={() => setMobileOpen(false)}
              className="inline-flex items-center justify-center mt-5 px-6 py-3 border border-primary/50 text-primary text-xs uppercase tracking-[0.25em] font-medium hover:bg-primary hover:text-primary-foreground transition-all duration-500"
            >
              Inquire
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
