import { useEffect, useMemo, useRef, useState } from "react";
import { Search, ArrowRight, Building2, MapPin, Home, KeyRound, HandCoins } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { BUILDINGS } from "@/data/buildings";
import { AREAS } from "@/data/areas";
import HeroBackground from "./HeroBackground";

const SUGGESTED = [
  { label: "Design District", type: "area", slug: "design-district" },
  { label: "Sunny Isles", type: "area", slug: "sunny-isles" },
  { label: "Bal Harbour", type: "area", slug: "bal-harbour" },
  { label: "South of Fifth", type: "area", slug: "south-of-fifth" },
  { label: "Midtown", type: "area", slug: "midtown" },
  { label: "Brickell", type: "area", slug: "brickell" },
] as const;

const INTENT_ACTIONS = [
  { label: "Buy", intent: "buy", Icon: Home },
  { label: "Sell", intent: "sell", Icon: HandCoins },
  { label: "Rent", intent: "lease", Icon: KeyRound },
] as const;

type Suggestion = {
  kind: "building" | "area";
  slug: string;
  title: string;
  sub: string;
};

const Hero = () => {
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const navigate = useNavigate();
  const blurTimeout = useRef<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const suggestions = useMemo<Suggestion[]>(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    const buildings: Suggestion[] = BUILDINGS.filter(
      (b) =>
        b.name.toLowerCase().includes(q) ||
        b.neighborhood.toLowerCase().includes(q) ||
        b.architect.toLowerCase().includes(q) ||
        (b.profile?.searchAliases ?? []).some((alias) =>
          alias.toLowerCase().includes(q),
        ),
    )
      .slice(0, 4)
      .map((b) => ({
        kind: "building",
        slug: b.slug,
        title: b.name,
        sub: `${b.architect} · ${b.neighborhood}`,
      }));
    const areas: Suggestion[] = AREAS.filter(
      (a) =>
        a.name.toLowerCase().includes(q) ||
        a.signature.toLowerCase().includes(q),
    )
      .slice(0, 3)
      .map((a) => ({
        kind: "area",
        slug: a.slug,
        title: a.name,
        sub: a.signature,
      }));
    return [...areas, ...buildings].slice(0, 6);
  }, [query]);

  // Reset active index when suggestions change
  useEffect(() => {
    setActiveIndex(0);
  }, [query]);

  const goTo = (kind: "building" | "area", slug: string) => {
    navigate(kind === "building" ? `/building/${slug}` : `/area/${slug}`);
  };

  const goToIntent = (intent: (typeof INTENT_ACTIONS)[number]["intent"]) => {
    const params = new URLSearchParams({
      intent,
      interest:
        intent === "sell"
          ? "Selling address"
          : intent === "lease"
            ? "Rental residence search"
            : "Purchase residence search",
    });
    navigate(`/?${params.toString()}#consultation`);
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setOpen(true);
      setActiveIndex((i) => Math.min(i + 1, suggestions.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((i) => Math.max(i - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const pick = suggestions[activeIndex];
      if (pick) goTo(pick.kind, pick.slug);
    } else if (e.key === "Escape") {
      setOpen(false);
      inputRef.current?.blur();
    }
  };

  const showEmpty = open && query.trim().length > 0 && suggestions.length === 0;

  return (
    <section
      id="top"
      className="relative min-h-[100svh] flex items-center justify-center overflow-hidden scroll-mt-24"
    >
      <HeroBackground />

      <div className="relative z-10 container mx-auto px-5 sm:px-6 pt-24 sm:pt-28 pb-8 md:pb-12 text-center">
        <p className="eyebrow mb-5 sm:mb-6 animate-fade-in text-[10px] sm:text-xs">
          Private Miami Residence Guide
        </p>
        <h1 className="serif text-[2.75rem] sm:text-5xl md:text-7xl lg:text-[5.5rem] leading-[0.98] sm:leading-[1.05] tracking-tight text-foreground mb-5 sm:mb-6 max-w-5xl mx-auto animate-fade-up">
          Built for the <span className="italic gold-text">South Florida move.</span>
        </h1>
        <p className="text-sm sm:text-base md:text-lg text-foreground/78 max-w-2xl mx-auto mb-7 md:mb-10 leading-relaxed font-light">
          A curated guide to South Florida's most coveted addresses. Begin
          with a building or a neighborhood, then move with a clear private plan.
        </p>

        {/* Centered Google-like search */}
        <div className="relative max-w-2xl mx-auto animate-fade-up">
          <div className="mb-3 grid grid-cols-3 gap-2 rounded-2xl border border-primary/15 bg-background/35 p-1.5 backdrop-blur-md sm:inline-grid sm:w-auto sm:min-w-[360px]">
            {INTENT_ACTIONS.map(({ label, intent, Icon }) => (
              <button
                key={intent}
                type="button"
                onClick={() => goToIntent(intent)}
                className="group inline-flex items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-[10px] uppercase tracking-[0.22em] text-foreground/75 transition-all duration-300 hover:bg-primary/12 hover:text-primary"
              >
                <Icon className="h-3.5 w-3.5 text-primary/75 transition-colors group-hover:text-primary" strokeWidth={1.5} />
                {label}
              </button>
            ))}
          </div>
          <div className="search-glow glass-panel flex items-center gap-3 px-4 sm:px-5 py-4 sm:py-5 md:py-6 rounded-2xl sm:rounded-full">
            <Search className="w-4 h-4 sm:w-5 sm:h-5 text-primary shrink-0" strokeWidth={1.5} />
            <input
              ref={inputRef}
              type="text"
              value={query}
              onChange={(e) => {
                setQuery(e.target.value);
                setOpen(true);
              }}
              onFocus={() => setOpen(true)}
              onBlur={() => {
                blurTimeout.current = window.setTimeout(() => setOpen(false), 150);
              }}
              onKeyDown={onKeyDown}
              placeholder="Search building or neighborhood"
              className="min-w-0 flex-1 bg-transparent border-0 outline-none text-foreground placeholder:text-foreground/55 text-sm md:text-base font-light tracking-wide"
              aria-label="Search buildings and neighborhoods"
              aria-autocomplete="list"
              aria-expanded={open}
            />
            <button
              onClick={() => {
                const pick = suggestions[activeIndex] ?? suggestions[0];
                if (pick) goTo(pick.kind, pick.slug);
              }}
              className="hidden sm:inline-flex items-center gap-2 text-[10px] uppercase tracking-[0.3em] text-primary hover:text-primary-glow transition-colors"
            >
              Search
              <ArrowRight className="w-3.5 h-3.5" strokeWidth={1.5} />
            </button>
          </div>

          {/* Suggestions dropdown */}
          {open && suggestions.length > 0 && (
            <div
              className="absolute left-0 right-0 mt-3 glass-panel overflow-hidden text-left z-20 rounded-2xl animate-dropdown-in max-h-[48svh] overflow-y-auto"
              role="listbox"
            >
              {suggestions.map((s, i) => {
                const Icon = s.kind === "building" ? Building2 : MapPin;
                const active = i === activeIndex;
                return (
                  <button
                    key={`${s.kind}-${s.slug}`}
                    role="option"
                    aria-selected={active}
                    onMouseEnter={() => setActiveIndex(i)}
                    onPointerDown={(e) => {
                      e.preventDefault();
                      if (blurTimeout.current) window.clearTimeout(blurTimeout.current);
                      goTo(s.kind, s.slug);
                    }}
                    className={`w-full flex items-center justify-between gap-3 sm:gap-4 px-4 sm:px-5 py-3.5 transition-colors border-b border-primary/10 last:border-0 ${
                      active ? "bg-primary/15" : "hover:bg-primary/10"
                    }`}
                  >
                    <div className="flex items-center gap-4 min-w-0">
                      <div
                        className={`flex items-center justify-center w-9 h-9 rounded-full shrink-0 transition-colors ${
                          active
                            ? "bg-primary/25 text-primary"
                            : "bg-primary/10 text-primary/80"
                        }`}
                      >
                        <Icon className="w-4 h-4" strokeWidth={1.5} />
                      </div>
                      <div className="min-w-0 text-left">
                        <div className="flex items-center gap-2">
                          <span className="text-[9px] uppercase tracking-[0.3em] text-primary/80">
                            {s.kind === "building" ? "Building" : "Area"}
                          </span>
                        </div>
                        <div className="serif text-base text-foreground truncate mt-0.5">
                          {s.title}
                        </div>
                        <div className="text-[10px] uppercase tracking-[0.25em] text-foreground/55 mt-0.5 truncate">
                          {s.sub}
                        </div>
                      </div>
                    </div>
                    <ArrowRight
                      className={`w-4 h-4 shrink-0 transition-all ${
                        active
                          ? "text-primary translate-x-0.5"
                          : "text-primary/60"
                      }`}
                      strokeWidth={1.5}
                    />
                  </button>
                );
              })}
            </div>
          )}

          {/* Empty state */}
          {showEmpty && (
            <div className="absolute left-0 right-0 mt-3 glass-panel rounded-2xl px-5 py-6 text-left z-20 animate-dropdown-in">
              <p className="text-sm text-foreground/75 font-light">
                No matches for{" "}
                <span className="text-primary italic">"{query}"</span>. Try a
                neighborhood name or a known building.
              </p>
            </div>
          )}

          {/* Suggested searches — softened */}
          <div className="mt-4 md:mt-5 flex flex-wrap items-center justify-center gap-2 max-w-sm sm:max-w-none mx-auto">
            <span className="basis-full sm:basis-auto text-[9px] sm:text-[10px] uppercase tracking-[0.3em] text-foreground/50 sm:mr-1">
              Try
            </span>
            {SUGGESTED.map((s, index) => (
              <button
                key={s.label}
                onClick={() => goTo(s.type as "building" | "area", s.slug)}
                className={`chip-soft text-[11px] sm:text-xs tracking-wide font-light px-3 py-1.5 sm:px-3.5 rounded-full text-foreground/75 ${
                  index > 3 ? "hidden sm:inline-flex" : ""
                }`}
              >
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 hairline" />
    </section>
  );
};

export default Hero;
