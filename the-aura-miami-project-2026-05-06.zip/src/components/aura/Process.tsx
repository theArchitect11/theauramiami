import { MessageSquare, FileText, Rocket } from "lucide-react";
import signalImg from "@/assets/process/signal.jpg";
import strategyImg from "@/assets/process/strategy.jpg";
import actionImg from "@/assets/process/action.jpg";

const steps = [
  {
    icon: MessageSquare,
    label: "Signal",
    body: "A private consultation. We listen first — your goals, timing, capital position, and the lifestyle you actually want.",
    image: signalImg,
    alt: "Soft golden light through silk curtains in a Miami penthouse",
  },
  {
    icon: FileText,
    label: "Strategy",
    body: "A tailored plan: target submarkets, price discipline, relocation steps, and the right specialists assembled around you.",
    image: strategyImg,
    alt: "Architectural floor plan with brass pen on marble",
  },
  {
    icon: Rocket,
    label: "Action",
    body: "Coordinated execution with vetted partners. Clear next steps, no portal noise, no scattered advice.",
    image: actionImg,
    alt: "Brass key resting on travertine in warm sunlight",
  },
];

const Process = () => {
  return (
    <section id="process" className="relative py-24 md:py-32 overflow-hidden border-y border-primary/10 scroll-mt-24">
      <div className="container mx-auto px-6 relative">
        <div className="max-w-3xl mb-14 md:mb-20">
          <p className="eyebrow mb-6">Process</p>
          <h2 className="serif text-4xl md:text-6xl leading-[1.05]">
            The process is <span className="italic text-primary">simple.</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-8 md:gap-10">
          {steps.map((s, i) => (
            <div
              key={s.label}
              className="group relative overflow-hidden rounded-xl border border-primary/10 bg-card/50 transition-[border-color,box-shadow,transform] duration-300 hover:-translate-y-1 hover:border-primary/35 hover:shadow-elegant"
            >
              {/* Image header */}
              <div className="relative aspect-[16/10] overflow-hidden bg-muted">
                <img
                  src={s.image}
                  alt={s.alt}
                  loading="lazy"
                  decoding="async"
                  width={1024}
                  height={640}
                  className="w-full h-full object-cover opacity-90 transition-transform duration-700 ease-out group-hover:scale-[1.03]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
                {/* Floating numeral */}
                <span className="absolute top-4 right-5 serif text-6xl md:text-7xl gold-text leading-none drop-shadow-lg">
                  {i + 1}
                </span>
                {/* Icon badge */}
                <div className="absolute bottom-4 left-5 w-11 h-11 rounded-full bg-background/80 backdrop-blur-md border border-primary/30 flex items-center justify-center shadow-gold">
                  <s.icon className="w-4 h-4 text-primary" strokeWidth={1.5} />
                </div>
              </div>

              {/* Body */}
              <div className="p-8 md:p-9">
                <div className="hairline mb-5 max-w-[80px]" />
                <h3 className="serif text-2xl md:text-3xl text-foreground mb-3">
                  {s.label}
                </h3>
                <p className="text-muted-foreground leading-relaxed text-sm md:text-base">
                  {s.body}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Process;
