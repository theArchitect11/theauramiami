import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, Building2, PenLine } from "lucide-react";
import { JOURNAL_ARTICLES } from "@/data/journal";

const featured = JOURNAL_ARTICLES.slice(0, 3);

const pillars = [
  {
    icon: Building2,
    label: "New development",
    text: "Editorial briefs on towers, districts, delivery stories, and the buildings reshaping Miami.",
  },
  {
    icon: PenLine,
    label: "Design partners",
    text: "Interior design, architecture, art, staging, and private collaborators around the residence.",
  },
  {
    icon: BookOpen,
    label: "The Aura edit",
    text: "Curated guides that compare buildings by lifestyle, service, view, pace, and long-term fit.",
  },
];

const JournalPreview = () => {
  return (
    <section id="journal" className="relative py-20 md:py-28 border-t border-primary/10 scroll-mt-32">
      <div className="container mx-auto px-5 sm:px-6">
        <div className="grid lg:grid-cols-[0.9fr_1.1fr] gap-10 md:gap-14 items-end mb-12 md:mb-16">
          <div>
            <p className="eyebrow mb-5 text-[10px] sm:text-xs">The Journal</p>
            <h2 className="serif text-4xl sm:text-5xl md:text-6xl leading-[1.05] mb-6">
              A magazine layer for{" "}
              <span className="italic text-primary">Miami residence culture.</span>
            </h2>
          </div>
          <div className="max-w-2xl lg:ml-auto">
            <p className="text-foreground/75 text-sm sm:text-base md:text-lg leading-relaxed font-light mb-6">
              The Aura Miami can publish market notes, new development briefs,
              architecture stories, neighborhood culture, and design collaborations
              that make the platform feel bigger than search.
            </p>
            <Link
              to="/journal"
              className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.24em] text-primary hover:text-foreground transition-colors"
            >
              Open the journal <ArrowRight className="w-4 h-4" strokeWidth={1.5} />
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4 md:gap-6 mb-10 md:mb-14">
          {pillars.map((pillar) => (
            <div key={pillar.label} className="border border-primary/12 bg-card/55 p-6 md:p-7">
              <pillar.icon className="w-5 h-5 text-primary mb-5" strokeWidth={1.5} />
              <h3 className="serif text-2xl text-foreground mb-3">{pillar.label}</h3>
              <p className="text-sm leading-relaxed text-muted-foreground">{pillar.text}</p>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-3 gap-4 md:gap-6">
          {featured.map((article) => (
            <Link
              key={article.slug}
              to="/journal"
              className="group overflow-hidden border border-primary/12 bg-card/70 hover:border-primary/45 hover:-translate-y-1 transition-all duration-500"
            >
              <div className="aspect-[16/10] overflow-hidden bg-muted">
                <img
                  src={article.image}
                  alt={article.title}
                  loading="lazy"
                  width={1280}
                  height={896}
                  className="h-full w-full object-cover transition-transform duration-1000 group-hover:scale-[1.08]"
                />
              </div>
              <div className="p-6 md:p-7">
                <div className="flex items-center justify-between gap-4 mb-5 text-[10px] uppercase tracking-[0.22em] text-primary/80">
                  <span>{article.category}</span>
                  <span className="text-foreground/45">{article.readTime}</span>
                </div>
                <h3 className="serif text-2xl md:text-3xl leading-tight mb-4 group-hover:text-primary transition-colors">
                  {article.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">{article.dek}</p>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default JournalPreview;
