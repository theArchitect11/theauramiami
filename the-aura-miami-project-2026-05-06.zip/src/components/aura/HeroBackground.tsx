import heroVilla from "@/assets/hero-1.jpg";

const HeroBackground = () => {
  return (
    <div className="absolute inset-0 overflow-hidden">
      <img
        src={heroVilla}
        alt="Private South Florida waterfront villa at golden hour"
        width={1920}
        height={1080}
        loading="eager"
        decoding="async"
        fetchPriority="high"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-background/10 via-background/25 to-background/75" />
    </div>
  );
};

export default HeroBackground;
