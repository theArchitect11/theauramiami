import { useState, FormEvent } from "react";
import { z } from "zod";
import { toast } from "sonner";
import { isLeadWebhookConfigured, N8N_WEBHOOK_URL } from "@/lib/webhook";
import { Send, CheckCircle } from "lucide-react";

const schema = z.object({
  full_name: z.string().trim().min(2, "Please enter your full name").max(100),
  email: z.string().trim().email("Please enter a valid email").max(255),
  phone: z.string().trim().min(7, "Please enter a valid phone").max(30),
  current_location: z.string().min(1, "Please select an option"),
  budget: z.string().min(1, "Please select a budget"),
  timeline: z.string().min(1, "Please select a timeline"),
  primary_goal: z.string().min(1, "Please select your intent"),
  financing_type: z.string().optional(),
  interest: z.string().trim().max(180).optional(),
  consent: z.literal(true, {
    errorMap: () => ({ message: "Consent is required to proceed" }),
  }),
});

type FormState = {
  full_name: string;
  email: string;
  phone: string;
  current_location: string;
  budget: string;
  timeline: string;
  primary_goal: string;
  financing_type: string;
  interest: string;
  consent: boolean;
};

const getInitialInterest = () => {
  if (typeof window === "undefined") return "";
  return new URLSearchParams(window.location.search).get("interest") || "";
};

const getInitialIntent = () => {
  if (typeof window === "undefined") return "";
  return new URLSearchParams(window.location.search).get("intent") || "";
};

const initial: FormState = {
  full_name: "",
  email: "",
  phone: "",
  current_location: "",
  budget: "",
  timeline: "",
  primary_goal: getInitialIntent(),
  financing_type: "",
  interest: getInitialInterest(),
  consent: false,
};

const fieldClass =
  "w-full bg-input/60 border border-primary/15 px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:border-primary focus:bg-input transition-colors duration-300";
const labelClass = "block text-[10px] sm:text-xs uppercase tracking-[0.18em] sm:tracking-[0.2em] text-muted-foreground mb-2";

const getUtm = () => {
  if (typeof window === "undefined") return {};
  const p = new URLSearchParams(window.location.search);
  return {
    utm_source: p.get("utm_source") || null,
    utm_medium: p.get("utm_medium") || null,
    utm_campaign: p.get("utm_campaign") || null,
    utm_term: p.get("utm_term") || null,
    utm_content: p.get("utm_content") || null,
  };
};

const getInquiryContext = () => {
  if (typeof window === "undefined") return {};
  const p = new URLSearchParams(window.location.search);
  return {
    interest: p.get("interest") || null,
    building: p.get("building") || null,
    area: p.get("area") || null,
    residence: p.get("residence") || null,
    residence_type: p.get("type") || null,
    price: p.get("price") || null,
    bedrooms: p.get("beds") || null,
    view: p.get("view") || null,
    intent: p.get("intent") || null,
  };
};

const ConsultationForm = () => {
  const [data, setData] = useState<FormState>(initial);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const context = getInquiryContext();
  const isSellInquiry = data.primary_goal === "sell" || context.intent === "sell";
  const hasContext = Boolean(
    context.interest || context.building || context.area || context.residence,
  );

  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setData((d) => ({ ...d, [key]: value }));
    if (errors[key as string]) {
      setErrors((e) => {
        const n = { ...e };
        delete n[key as string];
        return n;
      });
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    const result = schema.safeParse(data);
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach((issue) => {
        const k = issue.path[0] as string;
        if (!fieldErrors[k]) fieldErrors[k] = issue.message;
      });
      setErrors(fieldErrors);
      toast.error("Please complete all required fields.");
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        ...result.data,
        page_url: window.location.href,
        timestamp: new Date().toISOString(),
        source: "the-aura-miami-website",
        inquiry_context: getInquiryContext(),
        ...getUtm(),
      };

      if (!isLeadWebhookConfigured) {
        toast.error("Inquiry form is not connected yet. Please email concierge@theauramiami.com.");
        return;
      }

      const res = await fetch(N8N_WEBHOOK_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) throw new Error(`Request failed: ${res.status}`);

      setSubmitted(true);
      toast.success("Request received. We'll contact you shortly.");
      setData(initial);
    } catch (err) {
      console.error("Webhook submission failed", err);
      toast.error("Something went wrong. Please try again or email us directly.");
    } finally {
      setSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="glass-panel p-8 sm:p-10 md:p-14 text-center animate-fade-up">
        <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
          <CheckCircle className="w-8 h-8 text-primary" strokeWidth={1.5} />
        </div>
        <p className="eyebrow mb-4">Thank you</p>
        <h3 className="serif text-3xl md:text-4xl mb-4 gold-text">
          Request received.
        </h3>
        <p className="text-muted-foreground leading-relaxed max-w-md mx-auto">
          We'll contact you shortly to schedule your private strategy session.
        </p>
        <button
          onClick={() => setSubmitted(false)}
          className="mt-8 text-xs uppercase tracking-[0.25em] text-primary hover:text-primary-glow transition-colors"
        >
          Submit another inquiry
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="glass-panel p-5 sm:p-8 md:p-10 lg:p-12" noValidate>
      <div className="mb-7 md:mb-8">
        <p className="eyebrow mb-4 text-[10px] sm:text-xs">Private Consultation</p>
        <h3 className="serif text-3xl md:text-4xl text-foreground leading-tight mb-4">
          Begin a private strategy conversation.
        </h3>
        {hasContext && (
          <div className="border border-primary/20 bg-primary/8 px-4 py-3 text-xs text-muted-foreground">
            <div className="text-[9px] uppercase tracking-[0.28em] text-primary mb-1">
              Inquiry Context
            </div>
            <div className="text-foreground/85 leading-relaxed">
              {[context.interest, context.price, context.bedrooms && `${context.bedrooms} bed`, context.view]
                .filter(Boolean)
                .join(" · ")}
            </div>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-5">
        <div className="md:col-span-2">
          <label className={labelClass} htmlFor="full_name">Full Name</label>
          <input id="full_name" type="text" className={fieldClass} value={data.full_name}
            onChange={(e) => update("full_name", e.target.value)} maxLength={100} />
          {errors.full_name && <p className="text-destructive text-xs mt-1.5">{errors.full_name}</p>}
        </div>

        <div>
          <label className={labelClass} htmlFor="email">Email</label>
          <input id="email" type="email" className={fieldClass} value={data.email}
            onChange={(e) => update("email", e.target.value)} maxLength={255} />
          {errors.email && <p className="text-destructive text-xs mt-1.5">{errors.email}</p>}
        </div>

        <div>
          <label className={labelClass} htmlFor="phone">Phone</label>
          <input id="phone" type="tel" className={fieldClass} value={data.phone}
            onChange={(e) => update("phone", e.target.value)} maxLength={30} />
          {errors.phone && <p className="text-destructive text-xs mt-1.5">{errors.phone}</p>}
        </div>

        <div>
          <label className={labelClass} htmlFor="current_location">Current Location</label>
          <select id="current_location" className={fieldClass} value={data.current_location}
            onChange={(e) => update("current_location", e.target.value)}>
            <option value="">Select…</option>
            <option>Canada</option>
            <option>United States</option>
            <option>Brazil</option>
            <option>Colombia</option>
            <option>Europe</option>
            <option>Other</option>
          </select>
          {errors.current_location && <p className="text-destructive text-xs mt-1.5">{errors.current_location}</p>}
        </div>

        <div>
          <label className={labelClass} htmlFor="budget">Estimated Budget</label>
          <select id="budget" className={fieldClass} value={data.budget}
            onChange={(e) => update("budget", e.target.value)}>
            <option value="">Select…</option>
            <option>$500K–$1M</option>
            <option>$1M–$2M</option>
            <option>$2M–$5M</option>
            <option>$5M+</option>
          </select>
          {errors.budget && <p className="text-destructive text-xs mt-1.5">{errors.budget}</p>}
        </div>

        <div>
          <label className={labelClass} htmlFor="timeline">Timeline</label>
          <select id="timeline" className={fieldClass} value={data.timeline}
            onChange={(e) => update("timeline", e.target.value)}>
            <option value="">Select…</option>
            <option>0–3 months</option>
            <option>3–6 months</option>
            <option>6–12 months</option>
            <option>12+ months</option>
          </select>
          {errors.timeline && <p className="text-destructive text-xs mt-1.5">{errors.timeline}</p>}
        </div>

        <div>
          <label className={labelClass} htmlFor="primary_goal">Buy / Rent Intent</label>
          <select id="primary_goal" className={fieldClass} value={data.primary_goal}
            onChange={(e) => update("primary_goal", e.target.value)}>
            <option value="">Select…</option>
            <option value="buy">Buy</option>
            <option value="lease">Rent / Lease</option>
            <option value="sell">Sell</option>
            <option value="invest">Invest</option>
            <option>Relocation</option>
          </select>
          {errors.primary_goal && <p className="text-destructive text-xs mt-1.5">{errors.primary_goal}</p>}
        </div>

        <div>
          <label className={labelClass} htmlFor="financing_type">Cash / Finance</label>
          <select id="financing_type" className={fieldClass} value={data.financing_type}
            onChange={(e) => update("financing_type", e.target.value)}>
            <option value="">Optional</option>
            <option value="cash">Cash</option>
            <option value="finance">Finance</option>
            <option value="cash_or_finance">Cash or finance</option>
            <option value="not_sure">Not sure yet</option>
          </select>
        </div>

        <div className="md:col-span-2">
          <label className={labelClass} htmlFor="interest">
            {isSellInquiry ? "Selling Address" : "Building, Area, or Residence"}
          </label>
          <input
            id="interest"
            type="text"
            className={fieldClass}
            value={data.interest}
            onChange={(e) => update("interest", e.target.value)}
            placeholder={
              isSellInquiry
                ? "Enter the property address you are considering selling"
                : "Example: Missoni Baia, Brickell, 3-bed bay view"
            }
            maxLength={180}
          />
        </div>

        <div className="md:col-span-2 mt-2">
          <label className="flex items-start gap-3 cursor-pointer group border border-primary/10 bg-background/25 p-4">
            <input
              type="checkbox"
              checked={data.consent}
              onChange={(e) => update("consent", e.target.checked)}
              className="mt-1 w-4 h-4 accent-primary cursor-pointer flex-shrink-0"
            />
            <span className="text-xs leading-relaxed text-muted-foreground group-hover:text-foreground/80 transition-colors">
              I agree to be contacted by SMS/email about my inquiry. Message and data
              rates may apply. I can opt out at any time. I agree to the{" "}
              <a href="/privacy" className="text-primary hover:text-primary-glow">
                privacy notice
              </a>
              .
            </span>
          </label>
          {errors.consent && <p className="text-destructive text-xs mt-1.5">{errors.consent}</p>}
        </div>

        <div className="md:col-span-2 mt-4">
          <button
            type="submit"
            disabled={submitting}
            className="w-full group relative inline-flex items-center justify-center px-6 sm:px-8 py-4 bg-gradient-gold text-primary-foreground text-xs uppercase tracking-[0.22em] sm:tracking-[0.3em] font-medium shadow-gold hover:shadow-[0_0_80px_-5px_hsl(var(--gold)/0.6)] transition-all duration-500 disabled:opacity-60 disabled:cursor-not-allowed"
          >
            {submitting ? "Submitting…" : "Request Consultation"}
            {!submitting && (
              <Send className="w-3.5 h-3.5 ml-3 transition-transform duration-500 group-hover:translate-x-1" strokeWidth={1.5} />
            )}
          </button>
        </div>
      </div>
    </form>
  );
};

export default ConsultationForm;
